//
//  ViewController_Map.swift
//  Puppy App
//
//  Created by Flora Wong on 8/12/15.
//  Copyright (c) 2015 Parse. All rights reserved.
//

import UIKit
import CoreLocation
import Parse
import MapKit


class ViewController_Map: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    var manager:CLLocationManager = CLLocationManager()
    
    var lat:CLLocationDegrees = CLLocationDegrees()
    
    var long:CLLocationDegrees = CLLocationDegrees()

    var coordinates : CLLocationCoordinate2D = CLLocationCoordinate2D()
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var mapView: MKMapView!

    @IBOutlet weak var btnMarkT: UIButton!
    
    
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        
        var newLocation = locations.last as! CLLocation
        
        lat = newLocation.coordinate.latitude
        long = newLocation.coordinate.longitude
        coordinates = manager.location.coordinate
        println("+++location fetched+++")
        println("Coordinates = \(lat), \(long)")
        
        manager.stopUpdatingLocation()
        
        centerMapOnLocation(newLocation)
        
        //save to parse
        var location = PFObject(className: "Location")
        location["CheckIn"] = PFGeoPoint(latitude: lat, longitude: long)
        location["User"] = PFUser.currentUser()
        location.saveInBackgroundWithBlock { (success, error) -> Void in
            if (error == nil) {
                println("+++location saved+++")
            } else {
                println(error)
            }
        }
        
        
    }
    
    //if location fetch: failed
    func failLocationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
        
        var error = String(error!.localizedDescription)
        println(error)
        
        var alert = UIAlertController(title: "Error Occured when Getting Current Location", message: error, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title:"Close", style:UIAlertActionStyle.Default, handler:nil))
        
        self.presentViewController(alert, animated: true, completion: nil)
        
    }

    

    
    //pin location on map
    @IBAction func mark(sender: AnyObject) {

        //query location back
        var currentLocationQuery = PFQuery(className: "Location")
        
        currentLocationQuery.orderByDescending("createdAt")
        
        currentLocationQuery.findObjectsInBackgroundWithBlock { (objects:[AnyObject]?, error) -> Void in
            if (error == nil) {
                if let objects = objects as? [PFObject] {
                    for object in objects {
                        let point = object["CheckIn"] as! PFGeoPoint
                        let annotation = MKPointAnnotation()
                        annotation.coordinate = CLLocationCoordinate2DMake(point.latitude, point.longitude)
                        annotation.title = PFUser.currentUser()?.username
                        
                        var confirmAddPinAlert = UIAlertController(title: "Ruff! This is my territory!", message: "Happy Pooping...or Peeing!", preferredStyle: UIAlertControllerStyle.Alert)
                     
                        confirmAddPinAlert.addAction(UIAlertAction(title:"Mark", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
                            self.mapView.addAnnotation(annotation)
                        }))
                        
                        confirmAddPinAlert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Default, handler: nil))
                        
                        self.presentViewController(confirmAddPinAlert, animated: true, completion:nil)
                
                    }
                }
            } else {
                var error = String(error!.localizedDescription)
                println(error)
                
                var alert = UIAlertController(title: "Error Occured when Adding Pin", message: error, preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title:"Close", style:UIAlertActionStyle.Default, handler:nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
        
    }

    //center map to current location
    let regionRadius: CLLocationDistance = 1000
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
            regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }

    @IBOutlet weak var btnSegmentedControl: UISegmentedControl!
    
    //MAP TYPE: Standard or Satellite
    @IBAction func indexChanged(sender: AnyObject) {
        
        
        
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            mapView.mapType = MKMapType.Standard
        case 1:
            mapView.mapType = MKMapType.Satellite
        default:
            mapView.mapType = MKMapType.Standard
        }
    }
    
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        //show current location on map
        func statusChanged(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
            mapView.showsUserLocation = (status == .AuthorizedWhenInUse)
        }
        
        manager.requestWhenInUseAuthorization()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
        
        mapView.delegate = self
        mapView.mapType = MKMapType.Standard
        mapView.showsUserLocation = true

        
        btnMarkT.layer.cornerRadius = 5
       
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

}
